#include "pch.h"
#include "dll1.h"

int __stdcall F(int x, int y)
{
	return x - y;
}
