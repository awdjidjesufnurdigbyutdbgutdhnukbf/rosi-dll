#pragma once

extern "C" __declspec(dllexport) int __stdcall F(int x, int y);
