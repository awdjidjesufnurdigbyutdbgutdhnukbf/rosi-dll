﻿#pragma comment(lib, "Dll1.lib")

#include <iostream>
#include "import.h"

int main()
{
    int x = 5, y = 69, z;
    z = F(x, y);
    std::cout << "F = " << z;
}
