#pragma once

extern "C" __declspec(dllimport) int __stdcall F(int x, int y);
