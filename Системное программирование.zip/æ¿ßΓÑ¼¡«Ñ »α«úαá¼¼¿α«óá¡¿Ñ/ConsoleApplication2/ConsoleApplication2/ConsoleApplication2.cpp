﻿#pragma comment(lib,"kernel32.lib")
#pragma comment(lib,"user32.lib") 

#include <iostream>
#include <locale>
#include <windows.h>

int main() {
    // Установка русскоязычной локали
    setlocale(LC_ALL, "Russian");

    // Загрузка DLL-библиотеки
    HINSTANCE hDLL = LoadLibraryA("..\\..\\..\\Dll1\\x64\\Debug\\Dll1.dll");

    if (hDLL != NULL) {
        // Определение типа для функции F из загруженной библиотеки
        typedef int(__stdcall* FTYPE)(int, int);
        FTYPE f;

        // Получение адреса функции F из загруженной библиотеки
        f = (FTYPE)(GetProcAddress(hDLL, "F"));

        if (f != NULL) {
            // Вызов функции F с передачей ей двух аргументов
            int result = f(1000000, 1);
            std::cout << "Результат: " << result << std::endl;
        }
        else
        {
            // Вывод сообщения об ошибке, если не удалось получить адрес функции F
            std::cout << "Не удалось получить адрес функции!" << std::endl;
        }

        // Выгрузка DLL-библиотеки
        FreeLibrary(hDLL);
    }
    else {
        // Вывод сообщения об ошибке, если не удалось загрузить библиотеку
        std::cout << "Не удалось загрузить библиотеку!" << std::endl;
    }
}
